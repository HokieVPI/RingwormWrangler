// SPDX-License-Identifier: MIT
// Copyright (c) 2025 Truesense Srl

#ifndef UWBDLTDOATAG_HPP
#define UWBDLTDOATAG_HPP


#include "UWB.hpp"
#include "UWBSession.hpp"

class UWBDltdoaTag : public UWBSession {
public:     
    UWBDltdoaTag(uint32_t session_ID, UWBMacAddress srcAddr, 
                 uint8_t rangingroundIndexList[], uint8_t rangingroundIndexListSize)
        : roundsIndexList(rangingroundIndexList),
          roundsIndexListSize(rangingroundIndexListSize) 
    {
        sessionID(session_ID);
        sessionType(uwb::SessionType::RANGING);
        
        // Set ranging parameters using correct method names
        rangingParams.deviceRole(uwb::DeviceRole::DL_TDOA_TAG);
        rangingParams.deviceType(uwb::DeviceType::CONTROLEE);
        rangingParams.multiNodeMode(uwb::MultiNodeMode::ONE_TO_MANY);
        rangingParams.rangingRoundUsage(uwb::RangingMethod::DL_TDOA);
        rangingParams.scheduledMode(uwb::ScheduledMode::TIME_SCHEDULED);
        rangingParams.deviceMacAddr(srcAddr);
        
        // Add app parameters using correct method names
        appParams.rangingDuration(200);
        appParams.slotPerRR(10);
        appParams.slotDuration(1200);
        appParams.frameConfig(uwb::RfFrameConfig::SP1);
        appParams.channel(9);
        appParams.stsConfig(uwb::StsConfig::StaticSts);
        appParams.preambleCodeIndex(10);
        appParams.sfdId(0);
        appParams.noOfControlees(1);
        
        // Enable session info notifications for DL-TDoA tag
        appParams.addOrUpdateParam(buildScalar(uwb::AppConfigId::SessionInfoNtf, 1));

        uwb::Status status = init();
        if(status != uwb::Status::SUCCESS) {
            status = updateActiveRoundsReceiver();
        }
    }

protected:
    uwb::Status updateActiveRoundsReceiver() {
        // Note: updateActiveRoundsReceiver may not be available in the HAL
        // If needed, this functionality may need to be implemented differently
        // if(roundsIndexListSize > 0 && roundsIndexList != nullptr) {
        //     return UWBHAL.updateActiveRoundsReceiver(sessionHdl,
        //                                            roundsIndexListSize,
        //                                            roundsIndexList,
        //                                            &notActivatedRounds);
        // }
        return uwb::Status::FAILED;
    }

private:
    uint8_t notActivatedRounds;
    uint8_t* roundsIndexList;
    uint8_t roundsIndexListSize;
};

#endif /* UWBDLTDOATAG_HPP */

// SPDX-License-Identifier: MIT
// Copyright (c) 2025 Truesense Srl

#ifndef UWBDLTDOAINITIATOR_HPP
#define UWBDLTDOAINITIATOR_HPP

#define DLTDOA_ANCHOR1_TIMEBASE_64BIT 0x02


#include "UWB.hpp"
#include "UWBSession.hpp"
#include "UWBAnchorCoordinates.hpp"
#include "UWBActiveRounds.hpp"
#include "UWBMacAddressList.hpp"

class UWBDltdoaInitiator : public UWBSession {
public:     
    UWBDltdoaInitiator(uint32_t session_ID, UWBMacAddress srcAddr, 
                       UWBAnchorCoordinates coords, UWBMacAddressList dstAddrs, 
                       UWBActiveRounds rounds)
        : anchorCoordinates(coords), destAddrs(dstAddrs) 
    {
        sessionID(session_ID);
        sessionType(uwb::SessionType::RANGING);
        
        // Set ranging parameters using correct method names
        rangingParams.deviceRole(uwb::DeviceRole::DL_TDOA_ANCHOR);
        rangingParams.deviceType(uwb::DeviceType::CONTROLLER);
        rangingParams.multiNodeMode(uwb::MultiNodeMode::ONE_TO_MANY);
        rangingParams.rangingRoundUsage(uwb::RangingMethod::DL_TDOA);
        rangingParams.scheduledMode(uwb::ScheduledMode::TIME_SCHEDULED);
        rangingParams.deviceMacAddr(srcAddr);
        
        // Add app parameters using correct namespace and helper functions
        appParams.rangingDuration(200);
        appParams.slotPerRR(10);
        appParams.slotDuration(1200);
        appParams.frameConfig(uwb::RfFrameConfig::SP1);
        appParams.channel(9);
        appParams.stsConfig(uwb::StsConfig::StaticSts);
        appParams.preambleCodeIndex(10);
        appParams.sfdId(0);
        appParams.noOfControlees(dstAddrs.size());
        
        // Set destination addresses
        for(uint32_t i = 0; i < dstAddrs.size(); i++) {
            // Note: PeerAddress typically supports single address, may need multiple calls
            // or use a different method if multiple addresses are needed
        }
        
        // DL-TDoA specific parameters - these may need to be set via vendor params
        // or may not be available in this library version
        // TODO: Check if these parameters exist or need to be set differently:
        // - DLTDOA_ANCHOR_CFO
        // - DLTDOA_ANCHOR_LOCATION (coordinates)
        // - DLTDOA_TX_ACTIVE_RANGING_ROUNDS
        // - DL_TDOA_HOP_COUNT
        // - DLTDOA_TX_TIMESTAMP_CONF
        
        // Handle coordinates - may need vendor-specific parameter
        if(anchorCoordinates.areCoordinatesAvailable()) {
            // Coordinates may need to be set via vendor params or a different method
            // For now, we'll set basic parameters and coordinates may need manual configuration
        }
        
        // Enable session info notifications
        appParams.addOrUpdateParam(buildScalar(uwb::AppConfigId::SessionInfoNtf, 1));

        uwb::Status status = init();
        // Note: updateActiveRoundsAnchor may not be available in the HAL
        // If needed, this functionality may need to be implemented differently
        // if(status == uwb::Status::SUCCESS) {
        //     status = UWBHAL.updateActiveRoundsAnchor(sessionHdl, rounds.getSize(),
        //                                            dstAddrs.macTypeSize() == 2 ? 
        //                                            uwb::MacAddressMode::SHORT :
        //                                            uwb::MacAddressMode::LONG,
        //                                            rounds.getConfigs(),
        //                                            notActivatedRounds);
        // }
    }

private:
    UWBAnchorCoordinates anchorCoordinates;
    UWBMacAddressList destAddrs;
    uint8_t* notActivatedRounds;
    uint8_t* roundsIndexList;
    uint8_t roundsIndexListSize;
};

#endif /* UWBDLTDOAINITIATOR */
